const api_config = {
    port: 3000,
    conn_url: 'mongodb+srv://mmm:mmm@cluster0.gvyon.mongodb.net/projectDB?retryWrites=true&w=majority'

}


module.exports = api_config;